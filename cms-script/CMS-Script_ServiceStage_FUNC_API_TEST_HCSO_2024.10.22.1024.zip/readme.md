包名：ServiceStage_FUNC_API_TEST_HCSO
版本号：2024.10.22.1022           
前置步骤：
#obs创建桶并上传软件包(可在测试验收指南基础包资料中获取软件包下载地址),必备软件包：jar,war,nodejs8,php7
#已创建cse、cce、ecs、elb, 需在同vpc下
#已创建混合环境且环境已纳管cce、cse、ecs,elb等资源（[混合环境可通过api创建](https://support.huaweicloud.com/api-servicestage/servicestage_06_0056.html)，body.deploy_mode=mixed）
#[ecs已安装agent](https://support.huaweicloud.com/usermanual-servicestage/servicestage_03_0021.html)，cce已创建节点
#注：以上资源附和要求即可，cce节点选择docker，4U8G内存，ecs两个选择2U4G即可，cse选择高可用或者单击集群均可，以上资源的vpc需保持一致

用例执行参数说明：必填项请务必按需填写
#拨测租户（必填）,若不支持账号密码访问，可忽略（用例需禁用）
domainname=paas_servicestage
#拨测子用户名（必填）
username=apitest
#拨测租户密码（必填）
pwd=helloworld
#项目ID，用例已自动化
project_id=b4ce81794a1546b49c3b4ce1dc72bcc2
#局点region（必填）
project_name=roma-guian-8
#ak/sk 必填
AKid=FWVZYWFL14MY0MA4LTP
SKid=U5edIOMHBYqkDV0ICDlYaQKv3vrgevHGtQq1Y2r2
#iam域名，后缀域名按照实际局点填写（必填）
iam_endpoint=https://iam.${project_name}.arm.ga8.cn
#servicestage域名（必填）
http.endpoint=https://servicestage.${project_name}.arm.ga8.com
#cse域名（必填）
cse_endpoint=https://cse.${project_name}.arm.ga8.com
#obs域名（必填）
obs_endpoint=https://obs.${project_name}.arm.ga8.com
#创建的servicestage混合环境id（必填）
env_id=f19eba41-a5cb-4219-907f-54980fcef8bc
#创建的cse id（必填）
env_cse_id=91fdb33a-ef78-4160-97c8-5824ddfe8ef0
#swr域名（必填）
swr_endpoint=swr.roma-guian-8.arm.ga8.com
#VPC参数（必填）
vpc_id=f23ae834-30e3-4c22-a20e-c065988db308
vpc_name=vpc-8e3a
vpc_subnet_id=2df1db71-e76e-4206-b031-58198ad8c564
vpc_subnet_cidr=192.168.0.0/24
#弹性公网IP(EIP)相关,如若不支持，按默认
env_elb_eip_id=100.95.147.44
env_elb_eip_name=ss
#集群相关（必填）
env_cluster_id=0e2d15d1-7cca-11ef-8990-0255ac10008d
env_cluster_name=cce-servicestage
env_cluster_namespace=default
#集群类型
cluster_type=ARM64
#集群节点内网ip
env_cluster_nodeip=192.168.0.195
#集群访问地址，需带上集群id
cce_endpoint=https://${env_cluster_id}.cce.${project_name}.arm.ga8.com
#ecs相关（必填）,创建的ecs id
env_ecs_id1=3d5cb0ad-3621-482a-aa2f-391a6cb6f4a8
env_ecs_id2=cdf84519-8566-497d-b4ee-3bf7fc8ede83
#elb相关（必填）
elb_id=2c79ea9b-cb2a-4422-81ff-111467c10d9e
elb_name=test-auto-00825
#swr组织名（必填）
artifact_namespace=aaaa
#obs桶（必填）
obs_bucket=wzh
#上传的obs软件包，必填（可在测试验收指南基础包资料中获取软件包下载地址）
obs_war=examples.war
obs_jar=example.jar
obs_nodejs=weathermapweb.zip
obs_php=php-hello-world.zip


Content-Type=application/json;charset=UTF-8

#jdk包的obs地址,技术栈使用，默认即可,zip包
jdk_url=obs://apitest/php-hello-world.zip