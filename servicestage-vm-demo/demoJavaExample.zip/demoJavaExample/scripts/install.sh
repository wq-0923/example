#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
JRE_HOME=${JRE_STACK_HOME}
#install tomcat
APP_USER=${APP_USER}
APP_GROUP=${APP_GROUP}
JAVA_TOOL_OPTIONS=${JAVA_TOOL_OPTIONS}
installLog="${LOG_PATH}/install_app.log"

function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | sudo tee -a ${installLog};
}


function main()
{
    writeLog "install..."
    sudo -- /bin/bash -c "chmod -R 755 ${APP_HOME}/scripts/* ${LOG_PATH};chown -R ${APP_USER}:${APP_GROUP} ${APP_HOME}/scripts/*.sh;chown -R ${APP_USER}:${APP_GROUP} ${LOG_PATH} ${JRE_STACK_HOME}/"
    writeLog "install success..."
}

main