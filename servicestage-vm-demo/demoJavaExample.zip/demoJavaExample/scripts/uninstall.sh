#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
uninstallLog="${LOG_PATH}/uninstall_app.log"

function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | sudo tee -a ${uninstallLog};
}
sudo rm -rf ${APP_HOME}/*
if [ "$?" != "0" ]
then
    writeLog "Error: remove application error!"
    exit 1
fi
writeLog "INFO: uninstall application success!"
