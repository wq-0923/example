#!/bin/bash
if  ps -ef | grep ${APP_HOME}/apache-tomcat-*/bin/bootstrap.jar | grep -v grep >/dev/null; then
  echo "success"
else
  echo "error: example is not running"
  exit 1
fi
