#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
. ${APP_HOME}/config/system.cfg
JRE_HOME=${JRE_STACK_HOME}
TOMCAT_HOME=${TOMCAT_STACK_HOME}

#install tomcat
APP_HTTP=true
LOG_FILE_PATH_APP=${LOG_PATH}
JAVA_TOOL_OPTIONS=${JAVA_TOOL_OPTIONS}

installLog="${LOG_PATH}/install_app.log"

function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | sudo tee -a ${installLog};
}

function exit_check() {
    code=$1
    msg=$2
    if [[ "$code" != "0" ]]
    then
        writeLog "[ERROR] $msg"
        exit ${code}
    fi
}

function replacePara()
{
    sWord=$1
    dWord=$2
    theFile=$3
    if [[ "$sWord" == "" || "$theFile" == "" ]]
    then
        writeLog "[ERROR] ReplacePara has empty param, \$1:$sWord, \$3:$theFile"
        return 1
    fi

    if [[ ! -f ${theFile} ]]
    then
        writeLog "[ERROR] File $theFile does not exist."
        return 1
    fi
    count=`grep -c "$sWord" ${theFile}`
    if [[ "${count}" == "0" ]];then
        return 0
    fi
    sed "s#$sWord#${dWord}#g" ${theFile} > ${theFile}.temp
    if [[ "$?" != "0" ]]
    then
        writeLog "[ERROR] Sed command in replacePara error."
        return 1
    fi
    mv -f ${theFile}.temp ${theFile}
}

function config_tomcat()
{   
    cp ${APP_HOME}/config/logging.properties  ${TOMCAT_HOME}/conf/logging.properties

    #配置日志路径和JRE HOME
    writeLog  "[INFO] LOG_PATH:${LOG_FILE_PATH_APP}"
    replacePara "@{LOG_FILE_PATH_APP}" "${LOG_FILE_PATH_APP}" ${TOMCAT_HOME}/conf/logging.properties
    exit_check $? "ReplacePara @{LOG_FILE_PATH_APP} error in logging.properties."

    replacePara "@{LOG_FILE_PATH_APP}" "${LOG_FILE_PATH_APP}" ${TOMCAT_HOME}/conf/server.xml
    exit_check $? "ReplacePara @{LOG_FILE_PATH_APP} error in server.xml."

    export JAVA_TOOL_OPTIONS=${JAVA_TOOL_OPTIONS}
}

function config_tomcat_port_protocol()
{
    writeLog "config_tomcat_port_protocol"
    if [[ "${APP_HTTP}" == "true" ]]
    then
        replacePara "@{http_port}" "${instance_port_port}" ${TOMCAT_HOME}/conf/server.xml
        exit_check $? "ReplacePara @{http_port} error in server.xml."

        replacePara "@{instance_port_ip}" "${instance_port_ip}" ${TOMCAT_HOME}/conf/server.xml
        exit_check $? "ReplacePara @{instance_port_ip} error in server.xml."

        replacePara "@{server_port}" "${server_port}" ${TOMCAT_HOME}/conf/server.xml
        exit_check $? "ReplacePara @{server_port} error in server.xml."
    fi
}

function copyWar()
{
  cp -r ${APP_HOME}/packages/examples.war ${TOMCAT_HOME}/
  replacePara "@{APP_PACKAGE_NAME}" "examples.war" ${TOMCAT_HOME}/conf/server.xml
  sudo -- /bin/bash -c "chmod -R 755 ${APP_HOME}/scripts/* ${LOG_PATH};chown -R ${APP_USER}:${APP_GROUP} ${APP_HOME}/scripts/start.sh;chown -R ${APP_USER}:${APP_GROUP} ${APP_HOME}/scripts/stop.sh;chown -R ${APP_USER}:${APP_GROUP} ${APP_HOME}/scripts/pre-stop.sh;chown -R ${APP_USER}:${APP_GROUP} ${APP_HOME}/scripts/check.sh;chown -R ${APP_USER}:${APP_GROUP} ${APP_HOME}/scripts/post-start.sh;chown -R ${APP_USER}:${APP_GROUP} ${LOG_PATH} ${TOMCAT_STACK_HOME} ${JRE_STACK_HOME}/"

}

function main()
{
    config_tomcat
    writeLog "1.config_tomcat success."
    config_tomcat_port_protocol
    writeLog "3.config_tomcat_port_protocol success."
    copyWar
    writeLog "application install success!"
}
main
