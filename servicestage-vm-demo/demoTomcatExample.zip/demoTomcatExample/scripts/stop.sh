#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
stopLog="${LOG_PATH}/stop_app.log"
function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | tee -a ${stopLog};
}
cd ${APP_HOME}
CURRENT_USER=`whoami`
if [ "${CURRENT_USER}" != "${APP_USER}" ]
then
    writeLog "ERROR:Please change run user to ${APP_USER}"
    exit 1
fi
IS_RUNNING_TOMCAT=`ps -ef|grep -v grep|grep ${TOMCAT_STACK_HOME}/bin/bootstrap.jar`
if [ "${IS_RUNNING_TOMCAT}" != "" ]
then
    bash ${TOMCAT_STACK_HOME}/bin/shutdown.sh
fi
writeLog "shutdown tomcat success!"