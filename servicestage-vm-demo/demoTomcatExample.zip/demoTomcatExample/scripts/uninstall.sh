#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
uninstallLog="${LOG_PATH}/uninstall_app.log"
function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | sudo tee -a ${uninstallLog};
}
cd ${APP_HOME}
#uninstall tomcat
IS_RUNNING_TOMCAT=`ps -ef|grep -v grep|grep ${TOMCAT_STACK_HOME}/bin/bootstrap.jar`
if [ "$IS_RUNNING_TOMCAT" != "" ]
then
    writeLog "ERROR:tomcat application is running on $IS_RUNNING_TOMCAT"
    exit 1
fi
is_application_dir=`echo ${APP_HOME}|grep /opt/application`
if [ -d ${APP_HOME} -a "${is_application_dir}" != "" ]
then
    sudo rm -rf ${APP_HOME}/*
    exit 0
fi
writeLog "ERROR:uninstall tomcat application, APP_HOME:${APP_HOME} is not exist"
